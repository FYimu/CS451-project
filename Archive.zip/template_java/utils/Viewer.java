package cs451.utils;

public interface Viewer {
    public void deliver(Message message);
}
